import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';
import { mockServer } from '../services/mockServer';

interface AuthContextType {
  user: User | null;
  login: (username: string, password?: string) => Promise<void>;
  register: (username: string, password?: string) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Check if user session exists in sessionStorage (simulating cookie)
  useEffect(() => {
    const storedUser = sessionStorage.getItem('chat_session_user');
    if (storedUser) {
      const parsedUser = JSON.parse(storedUser);
      setUser(parsedUser);
      // Re-connect to mock server as this user
      mockServer.login(parsedUser.username).catch(() => {
          sessionStorage.removeItem('chat_session_user');
          setUser(null);
      });
    }
  }, []);

  const login = async (username: string, password?: string) => {
    setIsLoading(true);
    try {
      const user = await mockServer.login(username, password);
      setUser(user);
      sessionStorage.setItem('chat_session_user', JSON.stringify(user));
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (username: string, password?: string) => {
    setIsLoading(true);
    try {
      const user = await mockServer.register(username, password);
      setUser(user);
      sessionStorage.setItem('chat_session_user', JSON.stringify(user));
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    mockServer.logout();
    sessionStorage.removeItem('chat_session_user');
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};