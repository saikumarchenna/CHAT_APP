import { User, Message, WebSocketMessage } from '../types';

const STORAGE_USERS_KEY = 'chat_app_users';
const STORAGE_MESSAGES_KEY = 'chat_app_messages';
const CHANNEL_NAME = 'chat_app_realtime_channel';

// Simulate a database delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

class MockServerService {
  private channel: BroadcastChannel;
  private listeners: ((msg: WebSocketMessage) => void)[] = [];
  private currentUser: User | null = null;

  constructor() {
    this.channel = new BroadcastChannel(CHANNEL_NAME);
    this.channel.onmessage = (event) => {
      this.notifyListeners(event.data);
    };

    // Clean up online status on unload
    window.addEventListener('beforeunload', () => {
      if (this.currentUser) {
        this.broadcast({
          type: 'USER_LEFT',
          payload: this.currentUser
        });
        this.updateUserStatus(this.currentUser.id, false);
      }
    });
  }

  // --- Auth Simulation ---

  private getUsers(): any[] {
    const users = localStorage.getItem(STORAGE_USERS_KEY);
    return users ? JSON.parse(users) : [];
  }

  private saveUsers(users: any[]) {
    localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(users));
  }

  private updateUserStatus(userId: string, isOnline: boolean) {
    const users = this.getUsers();
    const index = users.findIndex(u => u.id === userId);
    if (index !== -1) {
      users[index].isOnline = isOnline;
      users[index].lastSeen = Date.now();
      this.saveUsers(users);
    }
  }

  async login(username: string, password?: string): Promise<User> {
    await delay(800); // Fake network latency
    const users = this.getUsers();
    let user = users.find(u => u.username.toLowerCase() === username.toLowerCase());

    if (!user) {
      throw new Error("User not found");
    }

    // Check password (in a real app, this would be hashed)
    if (user.password && user.password !== password) {
      throw new Error("Invalid password");
    }
    
    user.isOnline = true;
    user.lastSeen = Date.now();
    
    this.saveUsers(users);
    
    // Remove password before returning/broadcasting
    const { password: _, ...safeUser } = user;
    this.currentUser = safeUser;

    // Broadcast join
    this.broadcast({
      type: 'USER_JOINED',
      payload: safeUser
    });

    return safeUser;
  }

  async register(username: string, password?: string): Promise<User> {
    await delay(800);
    const users = this.getUsers();
    
    if (users.find(u => u.username.toLowerCase() === username.toLowerCase())) {
      throw new Error("Username already taken");
    }

    const newUser = {
      id: crypto.randomUUID(),
      username,
      password, // Store password
      isOnline: true,
      lastSeen: Date.now(),
      avatarUrl: `https://ui-avatars.com/api/?name=${username}&background=random`
    };
    
    users.push(newUser);
    this.saveUsers(users);

    const { password: _, ...safeUser } = newUser;
    this.currentUser = safeUser;

    this.broadcast({
      type: 'USER_JOINED',
      payload: safeUser
    });

    return safeUser;
  }

  async logout() {
    if (this.currentUser) {
      this.updateUserStatus(this.currentUser.id, false);
      this.broadcast({
        type: 'USER_LEFT',
        payload: this.currentUser
      });
      this.currentUser = null;
    }
  }

  // --- Data Access ---

  async getOnlineUsers(): Promise<User[]> {
    await delay(300);
    const users = this.getUsers();
    // Sanitize users before returning
    return users.map(({ password, ...u }) => u);
  }

  async getMessageHistory(): Promise<Message[]> {
    await delay(400);
    const msgs = localStorage.getItem(STORAGE_MESSAGES_KEY);
    return msgs ? JSON.parse(msgs) : [];
  }

  // --- Real-time Simulation ---

  sendMessage(text: string) {
    if (!this.currentUser) return;

    const message: Message = {
      id: crypto.randomUUID(),
      senderId: this.currentUser.id,
      senderName: this.currentUser.username,
      text,
      timestamp: Date.now(),
      type: 'text'
    };

    // Save to "DB"
    const history = localStorage.getItem(STORAGE_MESSAGES_KEY);
    const messages: Message[] = history ? JSON.parse(history) : [];
    messages.push(message);
    // Keep only last 100 messages for demo
    if (messages.length > 100) messages.shift();
    localStorage.setItem(STORAGE_MESSAGES_KEY, JSON.stringify(messages));

    // Broadcast via "WebSocket"
    const wsMsg: WebSocketMessage = {
      type: 'MESSAGE',
      payload: message
    };
    
    // BroadcastChannel doesn't fire for the sender, so we must manually notify local listeners
    this.notifyListeners(wsMsg); 
    this.broadcast(wsMsg);
  }

  private broadcast(msg: WebSocketMessage) {
    this.channel.postMessage(msg);
  }

  subscribe(callback: (msg: WebSocketMessage) => void) {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter(l => l !== callback);
    };
  }

  private notifyListeners(msg: WebSocketMessage) {
    this.listeners.forEach(cb => cb(msg));
  }
}

export const mockServer = new MockServerService();