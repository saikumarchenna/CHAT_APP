import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { mockServer } from '../services/mockServer';
import { User, Message } from '../types';
import { MessageBubble } from '../components/MessageBubble';
import { Button } from '../components/Button';
import { Input } from '../components/Input';

export const ChatView: React.FC = () => {
  const { user, logout } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initial Data Load
  useEffect(() => {
    const initData = async () => {
      const [onlineUsers, history] = await Promise.all([
        mockServer.getOnlineUsers(),
        mockServer.getMessageHistory()
      ]);
      setUsers(onlineUsers);
      setMessages(history);
    };
    initData();
  }, []);

  // WebSocket Subscription
  useEffect(() => {
    const unsubscribe = mockServer.subscribe((msg) => {
      switch (msg.type) {
        case 'MESSAGE':
          setMessages(prev => [...prev, msg.payload]);
          break;
        case 'USER_JOINED':
          setUsers(prev => {
            const exists = prev.find(u => u.id === msg.payload.id);
            if (exists) return prev.map(u => u.id === msg.payload.id ? msg.payload : u);
            return [...prev, msg.payload];
          });
          break;
        case 'USER_LEFT':
          setUsers(prev => prev.map(u => 
            u.id === msg.payload.id ? { ...u, isOnline: false } : u
          ));
          break;
      }
    });
    return unsubscribe;
  }, []);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    mockServer.sendMessage(inputText.trim());
    setInputText('');
  };

  const onlineCount = users.filter(u => u.isOnline).length;

  return (
    <div className="flex h-screen bg-gray-100 overflow-hidden relative">
      
      {/* Mobile Sidebar Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-20 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar - Users List */}
      <aside className={`
        fixed md:relative z-30 w-64 h-full bg-white border-r border-gray-200 flex flex-col transition-transform duration-300
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
      `}>
        <div className="p-4 border-b border-gray-200 flex items-center justify-between">
          <div>
            <h2 className="font-bold text-gray-800">Online Users</h2>
            <p className="text-xs text-green-600 font-medium flex items-center gap-1">
              <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
              {onlineCount} active
            </p>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="md:hidden text-gray-500">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {users.sort((a,b) => (b.isOnline ? 1 : 0) - (a.isOnline ? 1 : 0)).map(u => (
            <div key={u.id} className={`flex items-center gap-3 p-2 rounded-lg transition-colors ${u.isOnline ? 'hover:bg-gray-50' : 'opacity-50'}`}>
              <div className="relative">
                <img src={u.avatarUrl} alt={u.username} className="w-8 h-8 rounded-full bg-gray-200" />
                {u.isOnline && (
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 border-2 border-white rounded-full"></span>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">{u.username}</p>
                <p className="text-xs text-gray-500 truncate">
                  {u.id === user?.id ? '(You)' : u.isOnline ? 'Online' : 'Offline'}
                </p>
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 border-t border-gray-200 bg-gray-50">
          <div className="flex items-center gap-3 mb-3">
            <img src={user?.avatarUrl} alt="Me" className="w-10 h-10 rounded-full bg-gray-300" />
            <div className="flex-1 min-w-0">
              <p className="font-medium text-gray-900 truncate">{user?.username}</p>
              <p className="text-xs text-gray-500">ID: {user?.id.slice(0, 8)}...</p>
            </div>
          </div>
          <Button variant="secondary" onClick={logout} className="w-full text-sm py-1.5">
            Log Out
          </Button>
        </div>
      </aside>

      {/* Main Chat Area */}
      <main className="flex-1 flex flex-col h-full w-full bg-slate-50 relative">
        {/* Header */}
        <header className="bg-white h-16 border-b border-gray-200 flex items-center px-4 justify-between shrink-0 shadow-sm z-10">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setSidebarOpen(true)}
              className="md:hidden p-2 -ml-2 text-gray-600 hover:bg-gray-100 rounded-lg"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            <div className="flex flex-col">
              <h1 className="font-bold text-gray-800 text-lg">Global Lounge</h1>
            </div>
          </div>
          <div className="flex -space-x-2">
            {users.slice(0, 3).map(u => (
              <img key={u.id} src={u.avatarUrl} className="w-8 h-8 rounded-full border-2 border-white" alt="" />
            ))}
            {users.length > 3 && (
              <div className="w-8 h-8 rounded-full border-2 border-white bg-gray-100 flex items-center justify-center text-xs text-gray-500 font-medium">
                +{users.length - 3}
              </div>
            )}
          </div>
        </header>

        {/* Messages List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-gray-400 opacity-60">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
              </svg>
              <p>No messages yet. Say hello!</p>
            </div>
          ) : (
            messages.map((msg, index) => {
              const prevMsg = messages[index - 1];
              const showSender = !prevMsg || prevMsg.senderId !== msg.senderId || (msg.timestamp - prevMsg.timestamp > 60000);
              
              return (
                <MessageBubble 
                  key={msg.id} 
                  message={msg} 
                  isOwn={msg.senderId === user?.id}
                  showSender={showSender}
                />
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Message Input */}
        <div className="p-4 bg-white border-t border-gray-200">
          <form onSubmit={handleSendMessage} className="flex gap-2 max-w-4xl mx-auto">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Type a message..."
              className="flex-1 bg-gray-100 text-gray-900 placeholder-gray-500 border-0 rounded-full px-5 py-3 focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all outline-none"
            />
            <button 
              type="submit"
              disabled={!inputText.trim()}
              className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white rounded-full p-3 transition-colors shadow-sm"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 transform rotate-90" viewBox="0 0 20 20" fill="currentColor">
                <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
              </svg>
            </button>
          </form>
        </div>
      </main>
    </div>
  );
};