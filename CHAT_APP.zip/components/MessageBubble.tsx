import React from 'react';
import { Message } from '../types';

interface MessageBubbleProps {
  message: Message;
  isOwn: boolean;
  showSender: boolean;
}

export const MessageBubble: React.FC<MessageBubbleProps> = ({ message, isOwn, showSender }) => {
  if (message.type === 'system') {
    return (
      <div className="flex justify-center my-2">
        <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
          {message.text}
        </span>
      </div>
    );
  }

  return (
    <div className={`flex flex-col ${isOwn ? 'items-end' : 'items-start'} mb-1 group`}>
      {showSender && !isOwn && (
        <span className="text-xs text-gray-500 ml-1 mb-0.5">{message.senderName}</span>
      )}
      <div 
        className={`max-w-[70%] px-4 py-2 rounded-2xl break-words shadow-sm relative text-sm ${
          isOwn 
            ? 'bg-blue-600 text-white rounded-br-none' 
            : 'bg-white border border-gray-100 text-gray-800 rounded-bl-none'
        }`}
      >
        {message.text}
      </div>
      <span className="text-[10px] text-gray-400 mt-0.5 opacity-0 group-hover:opacity-100 transition-opacity px-1">
        {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
      </span>
    </div>
  );
};